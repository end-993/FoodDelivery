from django.contrib import admin
from .models import Dania,Kategoria
# Register your models here.

admin.site.register(Dania)
admin.site.register(Kategoria)